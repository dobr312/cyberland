# Environment Configuration Guide

## Critical Environment Variables

This application requires the following environment variables to be configured in `frontend/.env`:

### Network Configuration

